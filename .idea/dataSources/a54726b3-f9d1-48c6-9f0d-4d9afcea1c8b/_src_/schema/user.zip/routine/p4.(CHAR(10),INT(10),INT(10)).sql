CREATE PROCEDURE p4(IN in_username CHAR(10), IN out_num1 INT(10), IN out_num2 INT(10))
  begin
	set @t1=0,@t2=0;
	select * from user;
	select count(*) into @t1 from user;
	set out_num1=@t1;
	
	select * from user where username like in_username;
	select count(*) into @t2 from user where username like in_username;
	set out_num2=@t2;
end;
